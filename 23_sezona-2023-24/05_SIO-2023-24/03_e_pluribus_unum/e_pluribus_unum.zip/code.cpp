#include <bits/stdc++.h>

void OdrediVreme(int N, int M, int* S, int *U, int *V, int *T)
{
    for (int i=1;i<=N;i++) T[i]=i;
}
