#include <bits/stdc++.h>
using namespace std;

long long Resi(int N, int* A, int K){
    return 2;
}
