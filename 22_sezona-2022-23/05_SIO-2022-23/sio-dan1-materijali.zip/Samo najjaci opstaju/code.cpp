#include <bits/stdc++.h>
using namespace std;

void Init(int N, int* A) {

}

int Query(int L,int R){
    return 1;
}
