#include <bits/stdc++.h>
using namespace std;

int Resi(int N, int* A){
    return 1;
}
