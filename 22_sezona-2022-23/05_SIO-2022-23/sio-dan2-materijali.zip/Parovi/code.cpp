#include <bits/stdc++.h>
using namespace std;

long long Resi(int N, int M, int K, int *U, int *V){
    return 7+2;
}
